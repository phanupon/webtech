<?php
$aduser = "phanupon";
$adpasswd = "81dc9bdb52d04dc20036dbd8313ed055";
//echo md5('1234');
?>

