<html>
    <head><meta charset="utf-8"></head>
    <body>
        
    
<?php
setcookie("adminpage");
?>
คุณได้ออกจากระบบแล้ว<br>
<input type="button" value="เข้าระบบ" onclick="location.href='login.php'">
</body>       
</html>