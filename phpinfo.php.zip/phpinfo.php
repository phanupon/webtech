<?php
echo 'hello';
phpinfo();
?>